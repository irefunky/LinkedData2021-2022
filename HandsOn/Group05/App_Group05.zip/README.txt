Instrucciones para uso de la app.

Abra el archivo .py y ejecute todas las celdas.
En la última celda se encuentra la interfaz interactiva.


En algunas queries se debería poder elegir el nombre de la empresa a consultar
O el distrito igualmente, todo mediante algún input.

No se ha podido implementar esa opción de ejecutar una query 
Según una variable a definir por el usuario mediante input, por lo tanto
Se han definido dichas queries con Empresas o Distritos elegidos manualmente
A modo de ejemplo.

IMPORTANTE: Los otros dos documentos de la carpeta no deben eliminarse ni moverse.